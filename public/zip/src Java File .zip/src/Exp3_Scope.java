import java.util.*;
public class Exp3_Scope {
    int num = 40;

	void func() {
		int num = 22;
		System.out.println("Local scope " + num);
		System.out.println("Global scope " + this.num);
		return ;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Scope and lifetime of variables\n");

		Exp3_Scope s = new Exp3_Scope();
		s.func();

		System.out.println("\nAnkit Gaur\nCSE-A\n47");
        sc.close();

	}
}
