class X {
    X() {
        System.out.println("Constructor of Class X");
    }
}

class Y extends X {
    Y() {
        super();
        System.out.println("Constructor of class Y");
    }
}

class Z extends X {
    Z() {
        super();
        System.out.println("Constructor of class Z");
    }
}

public class Exp7_hirarical_Inheritance {
    public static void main(String[] args) {
        Z ob1 = new Z();
        Y ob2 = new Y();
    }
}
