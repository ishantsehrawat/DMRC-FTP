import java.util.*;
public class Exp3_java_literals {

    public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Java Literals\n\n");

		int a = 100;
		int b = 0100;
		int c = 0x100;
		int d = 0b100;
		System.out.println("100 in decimal -> " + a);
		System.out.println("100 in octal -> " + b);
		System.out.println("100 in hexadecimal -> " + c);
		System.out.println("100 in binary -> " + d);

		System.out.println("\nAnkit Gaur\nCSE-A\n47");
        sc.close();
	}
}
