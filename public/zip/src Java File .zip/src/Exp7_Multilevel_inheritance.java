class E {
    E() {
        System.out.println("Constuctor of Class A");
    }
}

class F extends E {
    F() {
        super();
        System.out.println("Constructor of class B");
    }
}

class C extends F {
    C() {
        super();
        System.out.println("Constructor of class C");
    }
}

public class Exp7_Multilevel_inheritance {
    public static void main(String[] args) {
        C ob1 = new C();
    }
}
