import java.util.*;
public class Exp3_Dynamic_Intialization {
    public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Dynamic Initialization\n");

		System.out.print("Enter value of a: ");
		int a = sc.nextInt();
		System.out.print("\nEnter value of b: ");
		int b = sc.nextInt();
		int c = a * b;
		System.out.println("\na = " + a);
		System.out.println("b = " + b);
		System.out.println("c = a * b = " + c);
		System.out.println("\nAnkit Gaur\nCSE-A\n47");
        sc.close();
	}
}
