class Person {
    String name;
    int age;

    void display() {
        System.out.println("Name: " + name + "\nAge: " + age);
    }

    Person(int umar, String naam) {
        name = naam;
        age = umar;
    }
}

class Student extends Person {
    Student(int umar, String naam, int roll, String b) {
        super(umar, naam);
        rollno = roll;
        branch = b;
    }

    int rollno;
    String branch;

    void display() {
        super.display();
        ;
        System.out.println("Roll No: " + rollno + "\nBranch: " + branch);
    }
}

class Employee extends Person {
    Employee(int umar, String naam, int Ecn, String Dj) {
        super(umar, naam);
        Ecno = Ecn;
        Doj = Dj;
    }

    int Ecno;
    String Doj;

    void display() {
        super.display();
        System.out.println("EC no.: " + Ecno + "\nDate of joining: " + Doj);
    }
}

class Faculty extends Employee {
    Faculty(int umar, String naam, int Ecn, String Dj, String D) {
        super(umar, naam, Ecn, Dj);
        desig = D;
    }

    String desig;

    void display() {
        super.display();
        System.out.println("\nDesignation: " + desig);
    }
}

class Staff extends Employee {
    Staff(int umar, String naam, int Ecn, String Dj, String D) {
        super(umar, naam, Ecn, Dj);
        desig = D;
    }

    String desig;

    void display() {
        super.display();
        System.out.println("\nDesignation: " + desig);
    }
}

public class Exp8_Implement_interface {
    public static void main(String[] args) {
        Staff ob1 = new Staff(25, "jeetu", 8001, "12/07/1845", "a1");
        Faculty ob2 = new Faculty(35, "lucy", 1001, "22/06/0998", "devil");
        Employee ob3 = new Employee(40, "vaibhv", 4001, "10/10/2010");
        Student ob4 = new Student(19, "Ankit Gaur", 47, "CSE");
        Person ob5 = new Person(19, "Jake");
        System.out.println("\nClass Staff\n");
        ob1.display();
        System.out.println("\nClass Faculty\n");
        ob2.display();
        System.out.println("\nClass Employee\n");
        ob3.display();
        System.out.println("\nClass Student\n");
        ob4.display();
        System.out.println("\nClass Person\n");
        ob5.display();
    }
}
