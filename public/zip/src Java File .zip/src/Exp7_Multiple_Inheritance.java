class J {
    J() {
        System.out.println("Constructor of Class J");
    }
}

interface K {
    void print();
}

class L extends J implements K {
    L() {
        super();
        System.out.println("Constructor of class L");
    }

    @Override
    public void print() {
        System.out.println("Inside Interface K");
    }
}

public class Exp7_Multiple_Inheritance {
    public static void main(String[] args) {
        L ob1 = new L();
        ob1.print();
    }
}
