


class Stack {
    int size;
    int top;
    int arr[] ;

    Stack(int n) {
        size = n;
        arr = new int[2 * n];
        top = 1;
    }

    void push(int val) {
        if (top == size) {
            System.out.println("Overflow");
        } else {
            System.out.println("pushed " + val);
            arr[++top] = val;
        }
    }
    void pop() {
        if (top == -1) {
            System.out.println("Underflow");
        } else {
            System.out.println("popped " + arr[top]);
            top--;
        }
    }
    int topp() {
        if (top == -1) {
            return -1;
        }
        return arr[top];
    }
}


public class Exp2_Stack {
    public static void main(String[] args) {
        

        int n = 3;
        Stack st = new Stack(n);
        st.push(10);
        st.push(20);
        st.push(30);
        System.out.println(st.topp());
        st.pop();
        st.pop();
        st.pop();
    }
    
}
