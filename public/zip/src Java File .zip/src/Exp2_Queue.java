import java.util.*;

class Queue {
	int front;
    int  rear;
    int  size;
	int arr[] ;

	Queue(int n) {
		size = n;
		arr = new int[2 * n];
		front = -1;
		rear = -1;
	}

	void push(int n) {
		// check if queue is full
		if ((rear == size - 1 && front == 0) || (rear == front - 1)) {
			System.out.println("Overflow");
			return ;
		}
		if (front == -1) {
			front = 0;
			rear ++;
			arr[rear] = n;
		} else if (rear == size - 1 && front > 0) {
			rear = 0;
			arr[rear] = n;
		} else {
			rear++;
			arr[rear] = n;
		}
		System.out.println("Pushing " + n);
		System.out.println("Front " + front + " Rear " + rear);
	}

	void pop() {
		// check if queue is empty
		if (front == -1) {
			System.out.println("Underflow");
		} else {
			int d = arr[front];
			if (front == rear) {
				front = -1;
				rear = -1;
			} else if (front == size - 1) {
				front = 0;
			} else {
				front ++;
			}
			System.out.println("Popping " + d);
		}
		System.out.println("Front " + front + " Rear " + rear);
	}

	int frontt() {
		if (front == rear && front == -1 ) {
			return -1;
		}
		return arr[front];
	}
}

public class Exp2_Queue {
    public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of queue: ");
		int n = sc.nextInt();
		System.out.println("Pop - (1,val)\nPush - 2\nFront - 3\nExit - 0\nEnter your choice\n");
		Queue q = new Queue(n);

		int op = sc.nextInt();
		while (op != 0) {
			// 1 for push
			// 2 for pop
			// 3 for front
			if (op == 1) {
				int val = sc.nextInt();
				q.push(val);
			} else if (op == 3) {
				System.out.println("Front element is " + q.frontt());
			} else if (op == 2) {
				q.pop();
			}
			op = sc.nextInt();
		}
        sc.close();
	}
}
