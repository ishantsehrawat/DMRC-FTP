class parent {
    parent() {
        System.out.println("Constuctor of Class A");
    }
}

class child extends parent {
    child() {
        super();
        System.out.println("Constructor of class B");
    }
}

public class Exp7_Single_Inheritance {
    public static void main(String[] args) {
        child ob1 = new child();
    }
}
